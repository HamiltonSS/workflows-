# Testes Automatizados com Cypress - Sauce Demo

Este projeto realiza testes automatizados de login e carrinho de compras no site [SauceDemo](https://www.saucedemo.com/), utilizando Cypress.

## ✅ Funcionalidades Automatizadas
- Testes de login com diferentes entradas
- Adição de item ao carrinho após login

## ⚙️ Pré-requisitos
- Node.js (v16 ou superior)
- npm

## 📦 Instalação
```bash
npm install
```

## 🚀 Executar Testes
```bash
npx cypress open
# ou
npx cypress run
```

## 🔄 Integração Contínua
Este projeto utiliza GitHub Actions para executar os testes automaticamente a cada push.
