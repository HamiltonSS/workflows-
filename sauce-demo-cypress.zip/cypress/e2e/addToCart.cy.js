describe('Adicionar Item ao Carrinho', () => {
  beforeEach(() => {
    cy.login()
  })

  it('Adiciona uma mochila ao carrinho', () => {
    cy.addItemToCart('add-to-cart-sauce-labs-backpack')
  })
})
